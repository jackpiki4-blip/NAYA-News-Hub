NAYA - GitHub Mobile APK Build

1) Upload NAYA_PROJECT_PAYLOAD.zip to the root of your GitHub repository.
2) Create the file .github/workflows/build-apk.yml and paste the contents of build-apk.yml.
3) Commit both files.
4) Open Actions -> Build NAYA APK -> Run workflow.
5) Download the NAYA-News-Hub-debug artifact.
